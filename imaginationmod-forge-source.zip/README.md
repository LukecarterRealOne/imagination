# Imagination (Forge 1.20.1)

A **Wand of Imagination** with **73 abilities** in six categories, all drawn with dreamy, eerie, liminal-space VFX
(pale fluorescent yellow, pastel pinks and blues, drifting fog and ash, bruise-purple dread).

| Category  | Count | Flavour |
|-----------|-------|---------|
| Dream     | 9     | soft, protective, floaty |
| Liminal   | 10    | backrooms, poolrooms, empty malls, static, exits |
| Creation  | 15    | build it, summon it, imagine it into being |
| Reality   | 13    | bend gravity, time and space |
| Nightmare | 9     | shadow hands, whispers, uncanny smiles |
| Wonder    | 17    | starfall, comets, auroras, wishes, supernova |

## Use
- Get it: craft it (amethyst shard + nether star + 2 sticks, see the recipe) or `/give @s imaginationmod:dream_wand`
- **Right-click**: cast your selected ability (random if you haven't picked one)
- **Sneak + right-click**: roll a random ability
- **G**: open the menu (category tabs, hover for a description, "CAST NOW" mode to cast straight from the menu)

## Safety
- Built blocks (bridges, walls, domes, towers...) are temporary, only ever replace air, and are removed again on a timer
  (and on server stop). Nothing in your world gets destroyed.
- Attacks only hit hostile mobs. Players, pets, villagers and your imaginary friends are never targeted.

## Build
Push this folder to a GitHub repo -> **Actions** tab -> download the `imaginationmod-1.20.1-forge` artifact
(contains `imaginationmod-1.0.0.jar`). Or locally: JDK 17 + Gradle 8.8, `gradle build`.
Install on Minecraft 1.20.1 + Forge 47.x. No other mods needed.
