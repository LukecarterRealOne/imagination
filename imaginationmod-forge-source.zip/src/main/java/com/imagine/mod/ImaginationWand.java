package com.imagine.mod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class ImaginationWand extends Item {
    /** Ability each player picked in the menu (missing = random). */
    public static final Map<UUID, Integer> SELECTED = new HashMap<>();
    /** Players who currently can't be hurt (Intangible). */
    public static final Set<UUID> SHIELDED = new HashSet<>();

    public ImaginationWand(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player user, InteractionHand hand) {
        ItemStack stack = user.getItemInHand(hand);
        if (level instanceof ServerLevel sw) {
            int pick = user.isShiftKeyDown() ? -1 : SELECTED.getOrDefault(user.getUUID(), -1);
            cast(sw, user, pick);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    /** Cast ability `index` (anything out of range = random) and start its cooldown. */
    public static void cast(ServerLevel sw, Player user, int index) {
        int a = index;
        if (a < 0 || a >= Abilities.COUNT) a = sw.random.nextInt(Abilities.COUNT);
        Abilities.Ability ab = Abilities.ALL[a];
        Util.msg(user, "\u00a7d\u00a7o" + ab.name());
        try {
            ab.run().cast(sw, user);
        } catch (Exception ex) {
            ex.printStackTrace();
            Util.msg(user, "\u00a7cThe dream slipped away...");
        }
        user.getCooldowns().addCooldown(ImaginationMod.DREAM_WAND.get(), ab.cooldown());
    }

    /** Called from the menu packet. */
    public static void onSelect(ServerPlayer p, int ability, boolean castNow) {
        if (ability >= Abilities.COUNT) return;
        if (ability < 0) {
            SELECTED.remove(p.getUUID());
        } else {
            SELECTED.put(p.getUUID(), ability);
        }
        String label = ability < 0 ? "Random" : Abilities.ALL[ability].name();
        if (!castNow) {
            Util.msg(p, "\u00a7dSelected: \u00a7f" + label);
            return;
        }
        boolean holding = p.getMainHandItem().getItem() instanceof ImaginationWand
                || p.getOffhandItem().getItem() instanceof ImaginationWand;
        if (!holding) {
            Util.msg(p, "\u00a7cHold the Wand of Imagination to cast");
            return;
        }
        if (p.getCooldowns().isOnCooldown(ImaginationMod.DREAM_WAND.get())) {
            Util.msg(p, "\u00a7cStill recovering...");
            return;
        }
        cast(p.serverLevel(), p, ability);
    }

    /** A faint, drifting dream-aura while the wand is held. */
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (selected && level instanceof ServerLevel sw && entity.tickCount % 6 == 0) {
            Fx.burst(sw, ParticleTypes.WHITE_ASH, entity.getX(), entity.getY() + 1.0, entity.getZ(), 3, 0.9, 0.7, 0.9, 0);
            if (entity.tickCount % 12 == 0) {
                Fx.burst(sw, Pal.DREAM, entity.getX(), entity.getY() + 1.2, entity.getZ(), 1, 0.7, 0.6, 0.7, 0);
                Fx.burst(sw, ParticleTypes.END_ROD, entity.getX(), entity.getY() + 1.4, entity.getZ(), 1, 0.6, 0.5, 0.6, 0.01);
            }
        }
    }
}
