package com.imagine.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/** Dream (0-8) and Liminal (9-18). */
public final class PowersA {
    private PowersA() {}

    // ───────────────────────── DREAM ─────────────────────────

    static void daydream(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 400, 0));
        u.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, 2f, 0.6f);
        Fx.screen(sw, u.position(), 24, 0.35f, 0f, 1, 0xFFE8F4);
        Util.loop(60, 2, t -> {
            if (Util.gone(sw, u)) return;
            double a = t * 0.35;
            double x = u.getX(), y = u.getY(), z = u.getZ();
            Fx.burst(sw, Pal.DREAM, x + Math.cos(a) * 1.2, y + 0.3 + t * 0.03, z + Math.sin(a) * 1.2, 2, 0.1, 0.1, 0.1, 0);
            Fx.burst(sw, ParticleTypes.END_ROD, x + Math.cos(a + Math.PI) * 1.2, y + 0.6 + t * 0.03, z + Math.sin(a + Math.PI) * 1.2, 1, 0, 0, 0, 0.01);
            Fx.burst(sw, ParticleTypes.CLOUD, x, y + 0.1, z, 1, 0.7, 0.05, 0.7, 0);
        });
    }

    static void lucidSight(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0, false, false));
        for (Mob m : Util.foes(sw, u.position(), 28)) {
            m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 600, 0, false, false));
            Fx.burst(sw, ParticleTypes.ENCHANT, m.getX(), m.getY() + m.getBbHeight() + 0.3, m.getZ(), 20, 0.3, 0.3, 0.3, 0.5);
        }
        Fx.sound(sw, u.blockPosition(), SoundEvents.ENCHANTMENT_TABLE_USE, 2f, 0.7f);
        Fx.screen(sw, u.position(), 32, 0.3f, 0f, 1, 0xE8F4FF);
        Util.loop(24, 1, t -> Fx.ring(sw, ParticleTypes.ENCHANT, u.getX(), u.getY() + 1 + t * 0.08, u.getZ(), 1 + t * 1.1, 36));
    }

    static void pillowFort(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 2));
        u.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 1));
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_ACTIVATE, 2f, 1.6f);
        Util.loop(100, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 mid = u.position().add(0, 1, 0);
            Fx.sphere(sw, ParticleTypes.CLOUD, mid, 4.5, 20, t * 0.05);
            Fx.sphere(sw, Pal.PINK, mid, 4.6, 14, -t * 0.04);
            if (t % 4 == 0) {
                for (Mob m : Util.foes(sw, mid, 5.5)) Util.shove(m, u.position(), 0.6, 0.15);
            }
        });
    }

    static void sleepwalk(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 600, 2));
        u.addEffect(new MobEffectInstance(MobEffects.JUMP, 600, 1));
        u.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 600, 0));
        Fx.sound(sw, u.blockPosition(), SoundEvents.PHANTOM_FLAP, 2f, 0.6f);
        Util.loop(150, 2, t -> {
            if (Util.gone(sw, u)) return;
            Fx.burst(sw, ParticleTypes.WHITE_ASH, u.getX(), u.getY() + 0.1, u.getZ(), 6, 0.4, 0.05, 0.4, 0);
            Fx.burst(sw, Pal.LAVENDER, u.getX(), u.getY() + 0.3, u.getZ(), 2, 0.3, 0.2, 0.3, 0);
        });
    }

    static void dreamCatcher(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.ILLUSIONER_MIRROR_MOVE, 2f, 1.2f);
        Util.loop(200, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 mid = u.position().add(0, 1, 0);
            if (t % 3 == 0) {
                for (int k = 1; k <= 3; k++) Fx.ring(sw, Pal.CREAM, mid.x, mid.y, mid.z, k * 2.0, 20 + k * 6);
                Fx.sphere(sw, Pal.LAVENDER, mid, 6.0, 18, t * 0.03);
            }
            for (Projectile pr : sw.getEntitiesOfClass(Projectile.class, new AABB(mid, mid).inflate(7),
                    x -> x.getOwner() != u && !x.getTags().contains(Util.ALLY))) {
                Vec3 v = pr.getDeltaMovement();
                pr.setDeltaMovement(v.scale(-1.0));
                pr.setOwner(u);
                pr.hurtMarked = true;
                Fx.burst(sw, ParticleTypes.END_ROD, pr.getX(), pr.getY(), pr.getZ(), 8, 0.2, 0.2, 0.2, 0.1);
            }
        });
    }

    static void wakeUp(ServerLevel sw, Player u) {
        for (MobEffectInstance eff : new ArrayList<>(u.getActiveEffects())) {
            if (!eff.getEffect().isBeneficial()) u.removeEffect(eff.getEffect());
        }
        u.setHealth(u.getMaxHealth());
        u.getFoodData().setFoodLevel(20);
        u.clearFire();
        Fx.sound(sw, u.blockPosition(), SoundEvents.PLAYER_LEVELUP, 2f, 1.3f);
        Fx.screen(sw, u.position(), 32, 1f, 2f, 8, 0xFFFFFF);
        Util.loop(14, 1, t -> {
            Fx.ring(sw, Pal.WHITE, u.getX(), u.getY() + 0.2 + t * 0.15, u.getZ(), 0.5 + t * 0.4, 30);
            Fx.ring(sw, ParticleTypes.END_ROD, u.getX(), u.getY() + 0.2 + t * 0.15, u.getZ(), 0.5 + t * 0.3, 16);
        });
    }

    static void cloudNine(ServerLevel sw, Player u) {
        BlockPos base = u.blockPosition().below();
        Map<BlockPos, BlockState> blocks = new LinkedHashMap<>();
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                if (dx * dx + dz * dz <= 18) blocks.put(base.offset(dx, 0, dz), Blocks.WHITE_WOOL.defaultBlockState());
            }
        }
        TempBlocks.placeAll(sw, blocks, 300);
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 0.5f);
        Util.loop(20, 1, t -> {
            Fx.ring(sw, ParticleTypes.CLOUD, u.getX(), base.getY() + 1.0, u.getZ(), 0.5 + t * 0.22, 24);
            Fx.burst(sw, Pal.CREAM, u.getX(), base.getY() + 1.0, u.getZ(), 4, 3, 0.2, 3, 0);
        });
    }

    static void sweetDreams(ServerLevel sw, Player u) {
        Vec3 here = u.position();
        for (ServerPlayer p : Util.playersNear(sw, here, 14)) {
            p.heal(10f);
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 2));
            Fx.burst(sw, ParticleTypes.HEART, p.getX(), p.getY() + 1.5, p.getZ(), 10, 0.5, 0.5, 0.5, 0.1);
        }
        for (Mob friend : sw.getEntitiesOfClass(Mob.class, new AABB(here, here).inflate(14),
                x -> x.getTags().contains(Util.ALLY) || (x instanceof TamableAnimal t && t.isTame()))) {
            friend.heal(20f);
            Fx.burst(sw, ParticleTypes.HEART, friend.getX(), friend.getY() + 1.2, friend.getZ(), 6, 0.4, 0.4, 0.4, 0.1);
        }
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, 2f, 1.4f);
        Util.loop(20, 1, t -> {
            Fx.ring(sw, Pal.PINK, here.x, here.y + 0.2 + t * 0.12, here.z, 1 + t * 0.7, 30);
            Fx.burst(sw, ParticleTypes.END_ROD, here.x, here.y + 0.5 + t * 0.12, here.z, 3, 4, 0.1, 4, 0.01);
        });
    }

    static void petalRain(ServerLevel sw, Player u) {
        if (sw.dimension() == Level.OVERWORLD) sw.setWeatherParameters(0, 1200, true, false);
        u.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 0));
        Fx.sound(sw, u.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, 2f, 1.2f);
        Util.loop(100, 2, t -> {
            if (Util.gone(sw, u)) return;
            Fx.burst(sw, ParticleTypes.CHERRY_LEAVES, u.getX(), u.getY() + 7, u.getZ(), 40, 8, 2, 8, 0);
            Fx.burst(sw, Pal.PINK, u.getX(), u.getY() + 5, u.getZ(), 6, 7, 3, 7, 0);
        });
    }

    // ───────────────────────── LIMINAL ─────────────────────────

    static void corridorStep(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, 2f, 0.5f);
        if (!Util.blink(sw, u, 16)) {
            Util.msg(u, "\u00a7cThere is a wall where the hallway should be...");
            return;
        }
        Fx.screen(sw, u.position(), 24, 0.45f, 0f, 1, 0xFFF7B0);
    }

    static void poolrooms(ServerLevel sw, Player u) {
        final Vec3 c = u.position();
        u.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 200, 0));
        Fx.sound(sw, u.blockPosition(), SoundEvents.PORTAL_AMBIENT, 2f, 0.5f);
        Fx.screen(sw, c, 30, 0.4f, 0f, 1, 0xBFE9FF);
        Util.loop(100, 2, t -> {
            Fx.ring(sw, Pal.BLUE, c.x, c.y + 0.1, c.z, 1 + (t % 10) * 0.9, 40);
            Fx.burst(sw, ParticleTypes.GLOW, c.x, c.y + 0.5, c.z, 6, 8, 0.3, 8, 0);
            Fx.burst(sw, ParticleTypes.BUBBLE, c.x, c.y + 0.3, c.z, 5, 8, 0.2, 8, 0);
            if (t % 5 == 0) {
                for (Mob m : Util.foes(sw, c, 9)) {
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 40, 1, false, false));
                }
            }
        });
    }

    static void backroomsHaze(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 160, 1));
        Fx.screen(sw, u.position(), 30, 0.5f, 0f, 1, 0xF5EA8C);
        Util.loop(140, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 mid = u.position().add(0, 1.2, 0);
            if (t % 2 == 0) Fx.fog(sw, mid, 9, 14);
            Fx.burst(sw, Pal.HAZE, mid.x, mid.y, mid.z, 6, 8, 3, 8, 0);
            if (t % 4 == 0) {
                for (Mob m : Util.foes(sw, mid, 10)) m.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0, false, false));
            }
            if (t % 35 == 0) Fx.sound(sw, u.blockPosition(), SoundEvents.CONDUIT_AMBIENT, 2f, 0.5f);
        });
    }

    static void fluorescentFlicker(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.BEACON_AMBIENT, 3f, 2f);
        Util.loop(30, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 here = u.position();
            if (t % 4 == 0) Fx.screen(sw, here, 40, 0.9f, 0f, 1, (t % 8 == 0) ? 0xFFF7B0 : 0xFFFFFF);
            Fx.burst(sw, ParticleTypes.ELECTRIC_SPARK, here.x, here.y + 3.5, here.z, 8, 6, 0.3, 6, 0.3);
            Fx.burst(sw, Pal.CREAM, here.x, here.y + 3.4, here.z, 6, 6, 0.2, 6, 0);
            if (t % 6 == 0) {
                for (Mob m : Util.foes(sw, here, 16)) {
                    m.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 40, 0, false, false));
                    Util.hurt(sw, u, m, 3f);
                }
            }
        });
    }

    static void emptyMall(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, 3f, 0.5f);
        Fx.screen(sw, u.position(), 30, 0.3f, 0f, 1, 0xD8D8D8);
        Util.loop(100, 1, t -> {
            if (Util.gone(sw, u)) return;
            Vec3 here = u.position();
            Fx.fog(sw, here.add(0, 2, 0), 12, 8);
            Fx.burst(sw, Pal.GRAY, here.x, here.y + 2, here.z, 4, 12, 3, 12, 0);
            if (t % 10 == 0) {
                for (Mob m : Util.foes(sw, here, 14)) {
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 6, false, false));
                    m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 2, false, false));
                }
            }
        });
    }

    static void stairwellUp(ServerLevel sw, Player u) {
        Vec3 from = u.position();
        Util.launch(u, 0, 2.0, 0);
        u.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0));
        Fx.sound(sw, u.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 2f, 0.6f);
        Fx.screen(sw, from, 30, 0.4f, 1f, 6, 0xFFF7B0);
        Util.loop(30, 1, t -> {
            Fx.spiral(sw, ParticleTypes.END_ROD, from, 1.4, 18, 4, 40, t * 0.25);
            Fx.spiral(sw, Pal.HAZE, from, 1.8, 18, 3, 30, -t * 0.2);
        });
    }

    static void staticBurst(ServerLevel sw, Player u) {
        final Vec3 c = u.position().add(0, 1, 0);
        Fx.sound(sw, u.blockPosition(), SoundEvents.ELDER_GUARDIAN_CURSE, 1.5f, 1.8f);
        Util.loop(20, 1, t -> {
            Fx.screen(sw, c, 20, 0.5f, 1f, 2, (t % 2 == 0) ? 0xFFFFFF : 0x202020);
            for (int i = 0; i < 70; i++) {
                double ox = (sw.random.nextDouble() - 0.5) * 16;
                double oy = (sw.random.nextDouble() - 0.5) * 8;
                double oz = (sw.random.nextDouble() - 0.5) * 16;
                Fx.burst(sw, sw.random.nextBoolean() ? Pal.WHITE : Pal.BLACK, c.x + ox, c.y + oy, c.z + oz, 1, 0, 0, 0, 0);
            }
            if (t % 5 == 0) {
                for (Mob m : Util.foes(sw, c, 8)) {
                    Util.hurt(sw, u, m, 4f);
                    Util.shove(m, c, 0.5, 0.2);
                    m.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0, false, false));
                }
            }
        });
    }

    static void takeTheExit(ServerLevel sw, Player u) {
        Fx.sound(sw, u.blockPosition(), SoundEvents.PORTAL_AMBIENT, 3f, 0.5f);
        Fx.screen(sw, u.position(), 40, 0.6f, 0f, 1, 0xFFF7B0);
        Util.loop(40, 1, t -> {
            if (Util.gone(sw, u)) return;
            Fx.spiral(sw, Pal.HAZE, u.position(), 1.5, 2.5, 2, 24, t * 0.3);
            Fx.fog(sw, u.position().add(0, 1, 0), 2, 6);
        });
        Scheduler.later(42, () -> {
            if (Util.gone(sw, u)) return;
            Vec3 dest = null;
            if (u instanceof ServerPlayer sp) {
                BlockPos bed = sp.getRespawnPosition();
                if (bed != null && sp.getRespawnDimension() == sw.dimension()) {
                    dest = new Vec3(bed.getX() + 0.5, bed.getY() + 0.6, bed.getZ() + 0.5);
                }
            }
            if (dest == null) {
                if (sw.dimension() != Level.OVERWORLD) {
                    Util.msg(u, "\u00a7cThe exit is not in this place...");
                    return;
                }
                BlockPos top = sw.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, sw.getSharedSpawnPos());
                dest = new Vec3(top.getX() + 0.5, top.getY(), top.getZ() + 0.5);
            }
            Fx.fog(sw, u.position().add(0, 1, 0), 2, 30);
            Fx.screen(sw, u.position(), 40, 1f, 2f, 8, 0xFFFFFF);
            Util.tp(u, dest.x, dest.y, dest.z);
            Fx.fog(sw, dest.add(0, 1, 0), 2, 30);
            Fx.burst(sw, ParticleTypes.END_ROD, dest.x, dest.y + 1, dest.z, 40, 0.6, 1, 0.6, 0.1);
            Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, 2f, 0.4f);
        });
    }

    static void dejaVu(ServerLevel sw, Player u) {
        final Vec3 anchor = u.position();
        final float hp = u.getHealth();
        final Level where = u.level();
        Fx.sound(sw, u.blockPosition(), SoundEvents.ILLUSIONER_CAST_SPELL, 2f, 0.6f);
        Util.loop(25, 4, t -> {
            Fx.column(sw, Pal.LAVENDER, anchor, 2.5, 0.4, 0.3);
            Fx.ring(sw, ParticleTypes.REVERSE_PORTAL, anchor.x, anchor.y + 0.2, anchor.z, 1.2, 14);
        });
        Scheduler.later(101, () -> {
            if (Util.gone(sw, u) || u.level() != where) return;
            Fx.fog(sw, u.position().add(0, 1, 0), 1.5, 24);
            Util.tp(u, anchor.x, anchor.y, anchor.z);
            u.setHealth(Math.min(u.getMaxHealth(), Math.max(u.getHealth(), hp)));
            Fx.fog(sw, anchor.add(0, 1, 0), 1.5, 24);
            Fx.screen(sw, anchor, 30, 0.6f, 1f, 4, 0xE8E0FF);
            Fx.sound(sw, u.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, 2f, 0.7f);
        });
    }

    static void lightsOut(ServerLevel sw, Player u) {
        u.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 240, 0, false, false));
        u.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 160, 0));
        Fx.sound(sw, u.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, 3f, 0.6f);
        Fx.screen(sw, u.position(), 40, 0.9f, 0f, 1, 0x000000);
        for (Mob m : Util.foes(sw, u.position(), 20)) {
            m.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 160, 0, false, false));
            m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 1, false, false));
        }
        Util.loop(30, 1, t -> {
            Vec3 mid = u.position().add(0, 1, 0);
            Fx.sphere(sw, Pal.BLACK, mid, 3 + t * 0.6, 50, t * 0.1);
            Fx.burst(sw, ParticleTypes.SMOKE, mid.x, mid.y, mid.z, 10, 5, 2, 5, 0.01);
        });
    }
}
