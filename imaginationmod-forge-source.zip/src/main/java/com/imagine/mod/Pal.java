package com.imagine.mod;

import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.util.Mth;
import org.joml.Vector3f;

/** Dreamy / liminal colour palette: washed-out fluorescent yellow, pastels, and bruise-purple dread. */
public final class Pal {
    private Pal() {}

    private static DustParticleOptions d(float r, float g, float b, float s) {
        return new DustParticleOptions(new Vector3f(r, g, b), s);
    }

    public static final DustParticleOptions YELLOW = d(0.96f, 0.92f, 0.55f, 1.7f);
    public static final DustParticleOptions CREAM = d(1f, 0.97f, 0.8f, 1.4f);
    public static final DustParticleOptions PINK = d(1f, 0.72f, 0.88f, 1.5f);
    public static final DustParticleOptions BLUE = d(0.62f, 0.82f, 1f, 1.5f);
    public static final DustParticleOptions LAVENDER = d(0.76f, 0.66f, 1f, 1.5f);
    public static final DustParticleOptions MINT = d(0.7f, 1f, 0.85f, 1.5f);
    public static final DustParticleOptions VOID = d(0.28f, 0.12f, 0.42f, 1.8f);
    public static final DustParticleOptions BLACK = d(0.04f, 0.02f, 0.07f, 2.0f);
    public static final DustParticleOptions WHITE = d(1f, 1f, 1f, 1.5f);
    public static final DustParticleOptions GRAY = d(0.6f, 0.6f, 0.62f, 1.4f);

    public static final DustColorTransitionOptions DREAM = new DustColorTransitionOptions(
            new Vector3f(1f, 0.72f, 0.88f), new Vector3f(0.62f, 0.82f, 1f), 1.6f);
    public static final DustColorTransitionOptions HAZE = new DustColorTransitionOptions(
            new Vector3f(0.96f, 0.92f, 0.55f), new Vector3f(1f, 1f, 1f), 1.6f);
    public static final DustColorTransitionOptions DREAD = new DustColorTransitionOptions(
            new Vector3f(0.45f, 0.2f, 0.65f), new Vector3f(0.03f, 0.02f, 0.05f), 1.8f);
    public static final DustColorTransitionOptions AURORA = new DustColorTransitionOptions(
            new Vector3f(0.5f, 1f, 0.8f), new Vector3f(0.8f, 0.5f, 1f), 1.7f);

    /** Pastel rainbow dust for hue 0..1. */
    public static DustParticleOptions rainbow(float hue) {
        int c = Mth.hsvToRgb(hue - (float) Math.floor(hue), 0.55f, 1f);
        return d(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f, 1.4f);
    }
}
