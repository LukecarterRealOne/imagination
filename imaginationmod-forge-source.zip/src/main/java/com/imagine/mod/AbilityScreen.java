package com.imagine.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** The G-key menu: six category tabs, 73 abilities, hover for a description. */
public class AbilityScreen extends Screen {
    private static int page = 0;
    /** true = clicking an ability casts it right away (if you are holding the wand). */
    private static boolean castNow = false;

    public AbilityScreen() {
        super(Component.literal("Imagination"));
    }

    @Override
    protected void init() {
        // category tabs
        int tabW = 62, tabGap = 3, tabs = Abilities.CAT_NAMES.length;
        int tabX = this.width / 2 - (tabs * tabW + (tabs - 1) * tabGap) / 2;
        for (int c = 0; c < tabs; c++) {
            final int ci = c;
            Button tab = Button.builder(Component.literal(Abilities.CAT_NAMES[c]), b -> {
                page = ci;
                this.rebuildWidgets();
            }).bounds(tabX + c * (tabW + tabGap), 20, tabW, 16).build();
            tab.active = (c != page);
            this.addRenderableWidget(tab);
        }

        // abilities of the current category, 3 columns
        int cols = 3, bw = 130, bh = 18, gap = 3;
        int startX = this.width / 2 - (cols * bw + (cols - 1) * gap) / 2;
        int startY = 54;
        int from = Abilities.CAT_START[page];
        int to = Abilities.catEnd(page);
        for (int i = from; i < to; i++) {
            final int idx = i;
            int n = i - from;
            int x = startX + (n % cols) * (bw + gap);
            int y = startY + (n / cols) * (bh + gap);
            Abilities.Ability ab = Abilities.ALL[i];
            Button btn = Button.builder(Component.literal(ab.name()), b -> pick(idx))
                    .bounds(x, y, bw, bh)
                    .tooltip(Tooltip.create(Component.literal(ab.desc())))
                    .build();
            this.addRenderableWidget(btn);
        }

        // footer
        int fy = startY + 6 * (bh + gap) + 4;
        this.addRenderableWidget(Button.builder(Component.literal("Random roll"), b -> pick(-1))
                .bounds(this.width / 2 - 135, fy, 90, 18).build());
        this.addRenderableWidget(Button.builder(modeLabel(), b -> {
            castNow = !castNow;
            b.setMessage(modeLabel());
        }).bounds(this.width / 2 - 41, fy, 130, 18).build());
        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> this.onClose())
                .bounds(this.width / 2 + 93, fy, 42, 18).build());
    }

    private static Component modeLabel() {
        return Component.literal(castNow ? "Mode: CAST NOW" : "Mode: select only");
    }

    private void pick(int ability) {
        ImaginationMod.CHANNEL.sendToServer(new SelectPacket(ability, castNow ? 1 : 0));
        if (castNow) this.onClose();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, "\u00a7d\u00a7oImagination", this.width / 2, 6, 0xFFFFFF);
        g.drawCenteredString(this.font,
                "\u00a77Hover for details. Right-click with the wand casts your pick; sneak + right-click rolls a random one.",
                this.width / 2, 40, 0xAAAAAA);
        super.render(g, mx, my, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
