package com.imagine.mod;

import java.util.Random;

/** Plain client-side state for flash / shake (no client class references, safe to load anywhere). */
public class ClientState {
    public static float flash = 0f;
    public static int flashColor = 0xFFF07A;
    public static float shakeAmp = 0f;
    public static int shakeTicks = 0;
    public static int shakeMax = 1;
    public static final Random RNG = new Random();

    public static void receive(float f, float shake, int duration, int color) {
        if (f > flash) {
            flash = f;
            flashColor = color;
        }
        float current = shakeTicks > 0 ? shakeAmp * shakeTicks / shakeMax : 0f;
        if (shake >= current) {
            shakeAmp = shake;
            shakeMax = Math.max(1, duration);
            shakeTicks = shakeMax;
        }
    }

    public static void tick() {
        if (flash > 0) flash = Math.max(0f, flash - 0.035f);
        if (shakeTicks > 0) shakeTicks--;
    }
}
