package com.imagine.mod;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ImaginationMod.MOD_ID)
public class Events {
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        DamageSource src = event.getSource();
        // Intangible: nothing gets through (void / kill still work)
        if (ImaginationWand.SHIELDED.contains(player.getUUID()) && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            event.setCanceled(true);
            return;
        }
        // imaginary friends can never hurt any player
        Entity attacker = src.getEntity();
        Entity direct = src.getDirectEntity();
        if ((attacker != null && attacker.getTags().contains(Util.ALLY))
                || (direct != null && direct.getTags().contains(Util.ALLY))) {
            event.setCanceled(true);
        }
    }

    /** Friends left over from an old session (or past their time) fade away instead of staying forever. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        Entity e = event.getEntity();
        if (!e.getTags().contains(Util.ALLY)) return;
        Long expiry = Util.LIVE.get(e.getUUID());
        if (expiry == null || event.getLevel().getGameTime() > expiry) {
            event.setCanceled(true);
        }
    }
}
